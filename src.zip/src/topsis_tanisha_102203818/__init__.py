from .topsis import topsis
__version__ = "0.1.0"